﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class frmGradeList : Form
    {
        private int flag = 0;//0添加1修改
        private int editGradId = 0;
        private string oldname = null;
        public frmGradeList()
        {
            InitializeComponent();
        }

        private void frmGradeList_Load(object sender, EventArgs e)
        {
            txtGradeName.Text = "";
            flag = 0;
            btnAdd.Text = "添加";
            LoadGradeList();//加载年级列表
        }
        private void LoadGradeList()
        {
            string sql = "select gradeId,gradename from gradeInfo";
            DataTable dtGradeList = SqlHelper.GetDataTable(sql);

            dgvGradeList.DataSource = dtGradeList;
        }
        /// <summary>
        /// 不是年级信息提交，是添加状态设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddGrade_Click(object sender, EventArgs e)
        {
            if (flag != 0)
            {
                flag = 0;
                btnAdd.Text = "添加";
                txtGradeName.Text = "";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //接受年级信息
            string gradeName = txtGradeName.Text.Trim();
            //判空
            if (string.IsNullOrEmpty(gradeName))
            {
                MessageBox.Show("年级不能为空！", "添加年级", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //判存
            if (flag==0)//添加  整个年级查询  现在年级没在数据库
            {
                string sqlExits = "select count(1) from gradeinfo where GradeName=@GradeName";
                MySqlParameter[] paraNames =
                {
                    new MySqlParameter("@GradeName",gradeName),
                };
                SqlHelper.ExecuteScalar(sqlExits, paraNames);
                object oCount = SqlHelper.ExecuteScalar(sqlExits, paraNames);
                if (oCount != null && (Convert.ToInt32(oCount)) > 0)
                {
                    MessageBox.Show("年级已存在！", "添加年级", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
                string sqlAdd = "insert into gradeinfo(GradeName)values(@GradeName);select @@Identity";
                object oGradeId = SqlHelper.ExecuteScalar(sqlAdd, paraNames);
                if (oGradeId != null && (Convert.ToInt32(oGradeId)) > 0)
                {
                    MessageBox.Show("年级{gradeName}添加成功！", "添加年级", MessageBoxButtons.OK,
                         MessageBoxIcon.Information);
                    DataTable dtGradeList = (DataTable)dgvGradeList.DataSource;
                    //添加一行，同时加到数据源
                    DataRow dr = dtGradeList.NewRow();
                    dr["GradeId"] = int.Parse(oGradeId.ToString());
                    dr["GradeName"] = gradeName;
                    dtGradeList.Rows.Add(dr);
                    dgvGradeList.DataSource = dtGradeList;
                }
                else
                {
                    MessageBox.Show("年级{gradeName}添加失败！", "添加年级", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
            }
            else if (flag == 1)//修改  除了当前年级这条信息以外的信息查询  加载的年级在数据库
            {
                if (gradeName == oldname)
                {
                    MessageBox.Show("年级名称并未修改！", "修改年级", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
                string sqlExits = "select count(1) from gradeinfo where GradeName=@GradeName " +
                    "and GradeId<>@GradeId";
                MySqlParameter[] paras = 
                {
                    new MySqlParameter("GradeName",gradeName),
                    new MySqlParameter("GradeId",editGradId),
                };
                object oCount = SqlHelper.ExecuteScalar(sqlExits, paras);
                if (oCount != null && (Convert.ToInt32(oCount)) > 0)
                {
                    MessageBox.Show("年级已存在！", "添加年级", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
                //修改入库
                string sqlUpdate = "update gradeinfo set GradeNmae=@GradeNmae where GradeId=@GradeId";
                int count = SqlHelper.ExecuteNonQuery(sqlUpdate, paras);
                if (count > 0)
                {
                    MessageBox.Show("年级{gradeName}修改成功！", "修改年级", MessageBoxButtons.OK,
                         MessageBoxIcon.Information);
                    DataTable dtGradeList = (DataTable)dgvGradeList.DataSource;
                    //添加一行，同时加到数据源
                    DataRow[] rows= dtGradeList.Select("GradeId=" + editGradId);
                    DataRow dr = rows[0];
                    dr["GradeName"] = gradeName;
                    dgvGradeList.DataSource = dtGradeList;
                }
                else
                {
                    MessageBox.Show("年级{gradeName}修改失败！", "修改年级", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
            }
        }

        private void dgvGradeList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                //获取选择的单元格并判断是修改还是删除
                DataGridViewCell cell = dgvGradeList.Rows[e.RowIndex].Cells[e.ColumnIndex];
                DataRow dr = (dgvGradeList.Rows[e.RowIndex].DataBoundItem as DataRowView).Row;
                int editGradId = (int)dr["GradeId"];//年级编号
                if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "修改")
                {
                    //修改  年级名称加载到文本框
                    txtGradeName.Text = dr["GradeName"].ToString();
                    flag = 1;//改成修改状态
                    btnAdd.Text = "修改";
                    oldname= dr["GradeName"].ToString(); 
                }
                else if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "删除")
                {
                    if (MessageBox.Show("确定删除该班级信息？", "删除学生信" +
                        "息", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        //单条数据删除

                        //班级删除过程  班级--学生  先删除学生--再删除班级
                        string delStudent = "delete from StudentInfo where ClassId in (select classid from classinfo where " +
                            "GradeId=@GradeId)";
                        //删除班级信息
                        string delClass = "delete from ClassInfo where ClassId=@ClassId";
                        //删除年级
                        string delGrade = "delete from GradeInfo where GradeId=@GradeId";
                        //参数定义
                        MySqlParameter[] para =
                         {
                                new MySqlParameter("@GradeId",editGradId)
                         };
                        List<CommandInfo> listComs = new List<CommandInfo>();
                        CommandInfo comGrade = new CommandInfo()
                        {
                            CommandText = delGrade,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comGrade);
                        CommandInfo comClass = new CommandInfo()
                        {
                            CommandText = delStudent,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comGrade);
                        //执行  事务
                        bool b1 = SqlHelper.ExecuteTrans(listComs);
                        if (b1)
                        {
                            MessageBox.Show("所选的年级信息已删除", "删除年级信" +
                                 "息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //手动刷新
                            DataTable dtGrade = (DataTable)dgvGradeList.DataSource;
                            //dtStudent.DataSource=null
                            dtGrade.Rows.Remove(dr);
                            dgvGradeList.DataSource = dtGrade;
                        }
                        else
                        {
                            {
                                MessageBox.Show("所选的年级信息删除失败", "删除年级信" +
                                     "息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
        }
    }
}
