﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //获取用户输入信息
            string uName = txtUserName.Text.Trim();
            string uPwd = txtUserPwd.Text.Trim();
            //判断是否为空
            if (string.IsNullOrEmpty(uName) )
            {
                MessageBox.Show("请输入账户！", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Focus();
                return;
            }
            if (string.IsNullOrEmpty(uPwd))
            {
                MessageBox.Show("请输入密码！", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserPwd.Focus();
                return;
            }
            //与数据库通信  检查输入与数据库是否一致
            {
                //建立与数据库连接，连接字符串----钥匙
                //string connString = "server=localhost;database=studentdb;Uid=root;Pwd=123456;";//字符串,Intergrated Security=true(windows登录)
                //MySqlConnection conn = new MySqlConnection(connString);
                //写查询语句，
                //string sql = "select count(1) from UserInfo where UserName='" + uName +
                //    "' and UserPwd='" + uPwd + "'";
                string sql = "select count(1) from UserInfo where UserName=@UserName " +
                    "and UserPwd=@UserPwd";
                //MySqlParameter paraName = new MySqlParameter("@UserName",uName);
                //MySqlParameter paraPwd = new MySqlParameter("@UserPwd", uPwd);
                //参数化数组实现
                MySqlParameter[] paras =
               {
                    new MySqlParameter("@UserName",uName),
                    new MySqlParameter("@UserPwd", uPwd)
                };
                //创建Command对象，
                //MySqlCommand cmd = new MySqlCommand(sql,conn);
                //cmd.CommandType = CommandType.StoredProcedure;//存储过程
                //Parameters.Clear();
                //cmd.Parameters.Add(paraName);
                //cmd.Parameters.Add(paraPwd);
                //cmd.Parameters.AddRange(paras);
                //打开连接，
                //conn.Open();//最晚打开，最早关闭
                //执行命令，要求必须在连接状态，open
                //object o = cmd.ExecuteScalar();//执行查询返回结果集第一行第一列的值，忽略其他值
                //关闭连接，
                //conn.Close();
                //处理结果
                //SqlHelper helper = new SqlHelper();
                //object o = helper.ExecuteScalar(sql, paras);
                object o = SqlHelper.ExecuteScalar(sql, paras);
                //返回的结果进行不同的提示
                if (o == null || o == DBNull.Value|| (Convert.ToInt32(o))==0)
                {
                    MessageBox.Show("登录账户或密码错误，请检查！", "登录提示", MessageBoxButtons.OK
                        , MessageBoxIcon.Error);
                    txtUserName.Clear();
                    txtUserPwd.Clear();
                    txtUserName.Focus();

                }
                else
                {
                    MessageBox.Show("登录成功", "登录提示", MessageBoxButtons.OK
                        , MessageBoxIcon.Information);
                    //转回主页面
                    FrmMain frm=new FrmMain();
                    frm.Show();
                    this.Hide();
                }
            }
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //this.Close();
            Application.Exit();
        }
    }
}
