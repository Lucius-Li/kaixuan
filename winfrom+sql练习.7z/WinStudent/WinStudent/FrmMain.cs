﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinStudent
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void addStudent_Click(object sender, EventArgs e)
        {
            FrmAddStudent frmAddStudent = new FrmAddStudent();
            frmAddStudent.MdiParent = this;
            frmAddStudent.Show();//顶级窗体 不显示MDI容器
        }

        //查询页面不可打开多个，单例模式
        private void subStudentList_Click(object sender, EventArgs e)
        {
            bool b1 = CheckForm(typeof(FrmStudentList).Name);
            if (!b1)
            {
                FrmStudentList frmStudentList = new FrmStudentList();
                    //FrmStudentList.CreateInstance();
                frmStudentList.MdiParent = this;
                frmStudentList.Show();//顶级窗体 不显示MDI容器
            }
        }
        /// <summary>
        /// 检查窗体是否打开
        /// </summary>
        /// <param name="fromName"></param>
        /// <returns></returns>
        private bool CheckForm(string fromName)
        {
            bool b1 = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Name == fromName)
                {
                    b1 = true;
                    f.Activate();
                    break;
                }
            }
            return b1;
        }

        private void addClass_Click(object sender, EventArgs e)
        {
            FrmAddClass frmAddClass = new FrmAddClass();
            frmAddClass.MdiParent = this;
            frmAddClass.Show();//顶级窗体 不显示MDI容器
        }

        private void subClassList_Click(object sender, EventArgs e)
        {
            bool b1 = CheckForm(typeof(frmClassList).Name);
            if (!b1)
            {
                frmClassList frmClassList = new frmClassList();
                //FrmStudentList.CreateInstance();
                frmClassList.MdiParent = this;
                frmClassList.Show();//顶级窗体 不显示MDI容器
            }
        }

        private void subGradeList_Click(object sender, EventArgs e)
        {
            bool b1 = CheckForm(typeof(frmGradeList).Name);
            if (!b1)
            {
                frmGradeList frmGradeList = new frmGradeList();
                //FrmStudentList.CreateInstance();
                frmGradeList.MdiParent = this;
                frmGradeList.Show();//顶级窗体 不显示MDI容器
            }
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result= MessageBox.Show("是否确认关闭系统？", "退出提示", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                //退出当前线程上的消息循环
                Application.ExitThread();
            }
            else
            {
                //手动取消
                e.Cancel = true;
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
