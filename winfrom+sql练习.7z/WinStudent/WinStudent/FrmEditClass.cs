﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinStudent
{
    public partial class FrmEditClass : Form
    {
        public FrmEditClass()
        {
            InitializeComponent();
        }
        private int classId = 0;
        private string oldName = "";
        private int oldGradeId = 0;
        private Action reLoad = null;//刷新列表页面所用
        /// <summary>
        /// 打开页面加载班级信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmEditClass_Load(object sender, EventArgs e)
        {
            InitGradeInfo();
            InitClassInfo();
        }

        private void InitGradeInfo()
        {
            string sql = "select gradeId,gradeName from gradeInfo";
            DataTable dtGradeList = SqlHelper.GetDataTable(sql);
            cboGrades.DataSource = dtGradeList;
            //年级名称----项
            cboGrades.DisplayMember = "GradeName";//显示的内容
            cboGrades.ValueMember = "GradeId";//值
            cboGrades.SelectedIndex = 0;
        }

        private void InitClassInfo()
        {
            //获取到classId
            if (this.Tag != null)
            {
                Tag tag = (Tag)this.Tag;
                classId = tag.EditId;
                reLoad = tag.ReLoad;//赋值委托
            }
            //查询数据
            string sql = "select classsname,gradeid,remark from classinfo " +
                " where ClassId=@ClassId ";
            MySqlParameter paraId = new MySqlParameter("@ClassId", classId);
            MySqlDataReader dr = SqlHelper.ExecuteReader(sql, paraId);
            //读取数据   只想前不后退  读一条 丢一条
            if (dr.Read())
            {
                txtClassName.Text = dr["ClassName"].ToString();
                oldName = txtClassName.Text.Trim();
                txtRemark.Text = dr["Remark"].ToString();
                int gradeId = (int)dr["GradeId"];
                oldGradeId = gradeId;
                cboGrades.SelectedValue = gradeId;
            }
            dr.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //获取页面输入
            string className = txtClassName.Text.Trim();
            int gradeId = (int)cboGrades.SelectedValue;
            string remark = txtRemark.Text.Trim();
            //判断是否为空
            if (string.IsNullOrEmpty(className))
            {
                MessageBox.Show("班级不能为空！", "修改班级", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //判断是否已存在
            string sqlExitsts = "select count(1) from classinfo where " +
                "Classname=@ClassName and GradeId=@GradeId ";
            if (className == oldName && gradeId == oldGradeId)
            {
                sqlExitsts += "  and ClassId<>@ClassId ";
            }
            MySqlParameter[] paras =
             {
                  new MySqlParameter("@ClassName",className),
                  new MySqlParameter("@GradeId",gradeId),
                  new MySqlParameter("@ClassId",classId)
              };
            //判断数据已在数据库存在，数据库会返回一个值
            object oCount = SqlHelper.ExecuteScalar(sqlExitsts, paras);
            if (oCount == null && (Convert.ToInt32(oCount)) == 0)
            {
                MessageBox.Show("班级名称已存在", "修改班级提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //修改提交
            string sqlUpdate = "update classinfo set ClassName=@ClassName " +
                " and GradeId=@GradeId and Remark=@Remark ";
            MySqlParameter[] parasUpdate =
            {
                        new MySqlParameter("@ClassName",className),
                        new MySqlParameter("@GradeId",gradeId),
                        new MySqlParameter("@Remark",remark),
                        new MySqlParameter("@Remark",classId),
             };
            //执行并返回值
            int count = SqlHelper.ExecuteNonQuery(sqlUpdate, parasUpdate);
            if (count > 0)
            {
                MessageBox.Show($"班级:{className},修改成功", "修改班级提示",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
                //刷新列表
                reLoad();

            }
            else
            {
                MessageBox.Show("修改添加失败", "修改班级提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
