﻿namespace WinStudent
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.myStudent = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudent = new System.Windows.Forms.ToolStripMenuItem();
            this.subStudentList = new System.Windows.Forms.ToolStripMenuItem();
            this.myClass = new System.Windows.Forms.ToolStripMenuItem();
            this.addClass = new System.Windows.Forms.ToolStripMenuItem();
            this.subClassList = new System.Windows.Forms.ToolStripMenuItem();
            this.myGrade = new System.Windows.Forms.ToolStripMenuItem();
            this.subGradeList = new System.Windows.Forms.ToolStripMenuItem();
            this.exit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myStudent,
            this.myClass,
            this.myGrade,
            this.exit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(500, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // myStudent
            // 
            this.myStudent.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudent,
            this.subStudentList});
            this.myStudent.Name = "myStudent";
            this.myStudent.Size = new System.Drawing.Size(83, 24);
            this.myStudent.Text = "学生管理";
            // 
            // addStudent
            // 
            this.addStudent.Name = "addStudent";
            this.addStudent.Size = new System.Drawing.Size(152, 26);
            this.addStudent.Text = "新增学生";
            this.addStudent.Click += new System.EventHandler(this.addStudent_Click);
            // 
            // subStudentList
            // 
            this.subStudentList.Name = "subStudentList";
            this.subStudentList.Size = new System.Drawing.Size(152, 26);
            this.subStudentList.Text = "学生列表";
            this.subStudentList.Click += new System.EventHandler(this.subStudentList_Click);
            // 
            // myClass
            // 
            this.myClass.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClass,
            this.subClassList});
            this.myClass.Name = "myClass";
            this.myClass.Size = new System.Drawing.Size(83, 24);
            this.myClass.Text = "班级管理";
            // 
            // addClass
            // 
            this.addClass.Name = "addClass";
            this.addClass.Size = new System.Drawing.Size(224, 26);
            this.addClass.Text = "新增班级";
            this.addClass.Click += new System.EventHandler(this.addClass_Click);
            // 
            // subClassList
            // 
            this.subClassList.Name = "subClassList";
            this.subClassList.Size = new System.Drawing.Size(224, 26);
            this.subClassList.Text = "班级列表";
            this.subClassList.Click += new System.EventHandler(this.subClassList_Click);
            // 
            // myGrade
            // 
            this.myGrade.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.subGradeList});
            this.myGrade.Name = "myGrade";
            this.myGrade.Size = new System.Drawing.Size(83, 24);
            this.myGrade.Text = "年级管理";
            // 
            // subGradeList
            // 
            this.subGradeList.Name = "subGradeList";
            this.subGradeList.Size = new System.Drawing.Size(224, 26);
            this.subGradeList.Text = "年级列表";
            this.subGradeList.Click += new System.EventHandler(this.subGradeList_Click);
            // 
            // exit
            // 
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(83, 24);
            this.exit.Text = "退出系统";
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 345);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMain";
            this.Text = "学生管理系统主页面";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem myStudent;
        private System.Windows.Forms.ToolStripMenuItem addStudent;
        private System.Windows.Forms.ToolStripMenuItem subStudentList;
        private System.Windows.Forms.ToolStripMenuItem myClass;
        private System.Windows.Forms.ToolStripMenuItem addClass;
        private System.Windows.Forms.ToolStripMenuItem subClassList;
        private System.Windows.Forms.ToolStripMenuItem myGrade;
        private System.Windows.Forms.ToolStripMenuItem subGradeList;
        private System.Windows.Forms.ToolStripMenuItem exit;
    }
}