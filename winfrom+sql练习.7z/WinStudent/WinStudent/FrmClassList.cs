﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class frmClassList : Form
    {
        private Action reLoad = null;
        public frmClassList()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 初始化年级列表、所有班级列表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmClassList_Load(object sender, EventArgs e)
        {
            InitGrades();
            InitAllClass();//加载所有班级信息
        }

        private void InitAllClass()
        {
            string sql = "select classid,classname,gradename,remark FROM classinfo a " +
                " inner join gradeinfo b on a.GradeId= b.GradeId";
            DataTable dtClasses = SqlHelper.GetDataTable(sql);

            dgvClassList.DataSource = dtClasses;
        }

        private void InitGrades()
        {
            string sql = "select gradeId,gradename from gradeinfo";
            DataTable dtGradeList = SqlHelper.GetDataTable(sql);
            //添加  请选择---项
            //添加一行
            DataRow dr = dtGradeList.NewRow();
            dr["GradeId"] = 0;
            dr["GradeName"] = "请选择";//到这只是创建
            //dtGradeList.Rows.Add(dr);//默认添加到最后
            dtGradeList.Rows.InsertAt(dr, 0);
            cboGrades.DataSource = dtGradeList;
            //年级名称----项
            cboGrades.DisplayMember = "GradeName";//显示的内容
            cboGrades.ValueMember = "GradeId";//值
            //cboGrades.SelectedIndex = 0;
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            //获取查询条件
            int gradeId = (int)cboGrades.SelectedValue;
            string className = txtClassName.Text.Trim();
            //
            string sql = "select classid,classname,gradename,remark from classinfo a " +
                " inner join gradeinfo b on a.GradeId= b.GradeId ";
            sql += " where 1=1 ";
            if (gradeId > 0)
            {
                sql += " and a.GradeId=@GradeId ";
            }
            if (!string.IsNullOrEmpty(className))
            {
                sql += " and a.ClassName like @ClassName ";
            }
            MySqlParameter[] paras =
            {
                new MySqlParameter("@GradeId",gradeId),
                new MySqlParameter("@ClassName", "%"+className+"%")
            };
            DataTable dtClasses = SqlHelper.GetDataTable(sql, paras);

            dgvClassList.DataSource = dtClasses;
        }

        private void dgvClassList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                //获取选择的单元格并判断是修改还是删除
                DataGridViewCell cell = dgvClassList.Rows[e.RowIndex].Cells[e.ColumnIndex];
                DataRow dr = (dgvClassList.Rows[e.RowIndex].DataBoundItem as DataRowView).Row;
                int classId = (int)dr["ClassId"];//班级编号
                if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "修改")
                {
                    //修改  
                    reLoad = InitAllClass;//赋值
                    FrmEditClass frmEdit = new FrmEditClass();
                    frmEdit.Tag = new Tag()
                    {
                        EditId = classId,
                        ReLoad = reLoad
                    };
                    frmEdit.MdiParent = this.MdiParent;
                    frmEdit.Show();
                }
                else if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "删除")
                {
                    if (MessageBox.Show("确定删除该班级信息？", "删除学生信" +
                        "+息", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        //单条数据删除
                        //班级删除过程  班级--学生  先删除学生--再删除班级
                        string delStudent = "delete from StudentInfo where ClassId=@ClassId";
                        //删除班级信息
                        string delClass = "delete from ClassInfo where ClassId=@ClassId";
                        //参数定义
                        MySqlParameter[] para =
                         {
                                new MySqlParameter("@ClassId", classId)
                         };
                        List<CommandInfo> listComs = new List<CommandInfo>();
                        CommandInfo comStudent = new CommandInfo()
                        {
                            CommandText = delStudent,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comStudent);
                        CommandInfo comClass = new CommandInfo()
                        {
                            CommandText = delStudent,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comStudent);
                        //执行  事务
                        bool b1 = SqlHelper.ExecuteTrans(listComs);
                        if (b1)
                        {
                            MessageBox.Show("所选的班级信息已删除", "删除学生信" +
                                 "息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //手动刷新
                            DataTable dtClass = (DataTable)dgvClassList.DataSource;
                            //dtStudent.DataSource=null
                            dtClass.Rows.Remove(dr);
                            dgvClassList.DataSource = dtClass;
                        }
                        else
                        {
                            {
                                MessageBox.Show("所选的班级信息删除失败", "删除学生信" +
                                     "息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //删除多条
            //选择框 选中的数据
            //获取要删除的数据ClassId
            //判断个数，=0没有选择，提示请选择，>0继续
            //删除操作   事务  sql事务（数据库启动）和代码中启动
            List<int> listIds = new List<int>();
            for (int i = 0; i < dgvClassList.Rows.Count; i++)
            {
                DataGridViewCheckBoxCell cell = dgvClassList.Rows[i].Cells["colCheck"] as DataGridViewCheckBoxCell;
                bool chk = Convert.ToBoolean(cell.Value);
                if (chk)
                {
                    //获取行数据
                    DataRow dr = (dgvClassList.Rows[i].DataBoundItem as DataRowView).Row;
                    int classId = (int)dr["ClassId"];
                    listIds.Add(classId);
                }
            }
            //真删除
            if (listIds.Count == 0)
            {
                MessageBox.Show("请选择要删除的班级信息", "删除班级信" +
                    "+息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if (MessageBox.Show("确定删除该班级信息？", "删除班级信" +
                        "+息", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    //单条数据删除
                    //班级删除过程  班级--学生  先删除学生--再删除班级
                    string delStudent = "delete from StudentInfo where ClassId=@ClassId";
                    //删除班级信息
                    string delClass = "delete from ClassInfo where ClassId=@ClassId";
                    List<CommandInfo> listComs = new List<CommandInfo>();
                    foreach (int id in listIds)
                    {
                        //参数定义
                        MySqlParameter[] para =
                         {
                               new MySqlParameter("@ClassId", id)
                         };
                        CommandInfo comStudent = new CommandInfo()
                        {
                            CommandText = delStudent,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comStudent);
                        CommandInfo comClass = new CommandInfo()
                        {
                            CommandText = delStudent,
                            IsProc = false,
                            Parameters = para
                        };
                        listComs.Add(comStudent);
                    }
                    bool b1 = SqlHelper.ExecuteTrans(listComs);
                    if (b1)
                    {
                        MessageBox.Show("所选的班级信息已删除", "删除学生信" +
                             "息", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        //手动刷新
                        DataTable dtClass = (DataTable)dgvClassList.DataSource;
                        //dtStudent.DataSource=null
                        string idStr = string.Join(",", listIds);
                        DataRow[] rows = dtClass.Select("ClassId in (" + idStr + ")");
                        foreach (DataRow dr in rows)
                        {
                            dtClass.Rows.Remove(dr);
                        }
                        dgvClassList.DataSource = dtClass;
                    }
                    else
                    {
                        {
                            MessageBox.Show("所选的班级信息删除失败", "删除学生信" +
                                 "息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
            }
        }
    }
}
