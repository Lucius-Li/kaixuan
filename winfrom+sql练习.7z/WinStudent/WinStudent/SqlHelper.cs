﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;

namespace WinStudent
{
    static  class SqlHelper
    {
        //
        //private string connString = "server=localhost;database=studentdb;Uid=root;Pwd=123456;";
        public static readonly string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
       /// <summary>
       /// 
       /// </summary>
       /// <param name="sql"></param>
       /// <param name="paras"></param>
       /// <returns></returns>
        public static object ExecuteScalar(string sql, params MySqlParameter[] paras)
        {
            object o = null;
            //链接字符串,Intergrated Security=true(windows登录)
            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                //创建Command对象，
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //cmd.CommandType = CommandType.StoredProcedure;//存储过程
                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(paras);
                //打开连接，
                conn.Open();//最晚打开，最早关闭
                            //执行命令，要求必须在连接状态，open
                o = cmd.ExecuteScalar();//执行查询返回结果集第一行第一列的值，忽略其他值
               //关闭连接，
                //conn.Close();
            }
            return o;
        }
        /// <summary>
        /// 返回一个DataTable
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="paras"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string sql,params MySqlParameter[]paras)
        {
            DataTable dt =new  DataTable();
            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                //创建Command对象，
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //cmd.CommandType = CommandType.StoredProcedure;//存储过程
                if (paras != null)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddRange(paras);
                }
                //打开连接，
                //conn.Open();//最晚打开，最早关闭
                //断开式链接 是不是不用连接数据库？不是
                //执行命令---一定是Command完成的
                MySqlDataAdapter da = new MySqlDataAdapter();//桥接器
                da.SelectCommand = cmd;

                //打开conn OPened
                //数据填充
                da.Fill(dt);
                //关闭conn
            }
            return dt;
        }
        /// <summary>
        /// 返回受影响的行数
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="paras"></param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string sql, params MySqlParameter[] paras)
        {
            int count = 0;
            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                //创建Command对象，
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //cmd.CommandType = CommandType.StoredProcedure;//存储过程
                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(paras);
                //打开连接，
                conn.Open();//最晚打开，最早关闭
                            //执行命令，要求必须在连接状态，open
                count = cmd.ExecuteNonQuery();//执行一个T-sql语句，返回受影响的行数
                                              //关闭连接，
                                              //conn.Close();
                cmd.Parameters.Clear();
            }
            return count;
        }
        /// <summary>
        /// 执行查询返回数据流
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="paras"></param>
        /// <returns></returns>
        public static MySqlDataReader ExecuteReader(string sql,params MySqlParameter[] paras)
        {
            MySqlConnection conn = new MySqlConnection(connString);
            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //if (paras.Length > 0)
                //{
                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(paras);
                //}
                MySqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                return dr;
            }
            catch(MySqlException ex)
            {
                conn.Close();
                throw new Exception("执行查询出现异常");

            }
        }
        public static bool ExecuteTrans(List<CommandInfo> comlist)
        {
            MySqlConnection conn = new MySqlConnection(connString);
            conn.Open();
            MySqlTransaction trans = conn.BeginTransaction();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conn;
            cmd.Transaction = trans;
            try
            {
                int count = 0;
                for (int i = 0; i < comlist.Count; i++)
                {
                    cmd.CommandText = comlist[i].CommandText;
                    if (comlist[i].IsProc)
                        cmd.CommandType = CommandType.StoredProcedure;
                    else
                        cmd.CommandType = CommandType.Text;
                    if (comlist[i].Parameters.Length > 0)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddRange(comlist[i].Parameters);
                    }
                    count += cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
                trans.Commit();
                return true;
            }
            catch(Exception ex)
            {
                trans.Rollback();
                throw new Exception("执行事务出现异常",ex);
            }

        }
    }
}
