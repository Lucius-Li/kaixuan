﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class FrmAddClass : Form
    {
        public FrmAddClass()
        {
            InitializeComponent();
        }

        private void FrmAddClass_Load(object sender, EventArgs e)
        {
            InitGradeList();
        }

        private void InitGradeList()
        {
            string sql = "select gradeId,gradeName from gradeInfo";
            DataTable dtGradeList = SqlHelper.GetDataTable(sql);
            cboGrades.DataSource = dtGradeList;
            //年级名称----项
            cboGrades.DisplayMember = "GradeName";//显示的内容
            cboGrades.ValueMember = "GradeId";//值
            cboGrades.SelectedIndex = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //信息获取
            string className = txtClassName.Text.Trim();
            int gradeId = (int)cboGrades.SelectedValue;
            string remark = txtRemark.Text.Trim();

            //判断是否为空
            if (string.IsNullOrEmpty(className))
            {
                MessageBox.Show("班级名称不能为空！", "添加班级提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //判断是否已经存在  数据库检查---进行数据库交互
            {
                string sqlExitsts = "select count(1) from classinfo where " +
                    "Classname=@ClassName and GradeId=@GradeId";
                MySqlParameter[] paras = 
                {
                    new MySqlParameter("@ClassName",className),
                    new MySqlParameter("@GradeId",gradeId)
                };
                //判断数据已在数据库存在，数据库会返回一个值
                object oCount = SqlHelper.ExecuteScalar(sqlExitsts, paras);
                if (oCount == null || oCount == DBNull.Value || (Convert.ToInt32(oCount)) == 0)
                {
                    //添加操作
                    string sqlAdd = "insert into classinfo" +
                        "(ClassName,GradeId,Remark)values" +
                        "(@ClassName,@GradeId,@Remark)";
                    MySqlParameter[] parasAdd = 
                    {
                        new MySqlParameter("@ClassName",className),
                        new MySqlParameter("@GradeId",gradeId),
                        new MySqlParameter("@Remark",remark),
                    };
                    //执行并返回值
                    int count = SqlHelper.ExecuteNonQuery(sqlAdd, parasAdd);
                    if (count > 0)
                    {
                        MessageBox.Show($"班级:{className},添加成功", "添加班级提示",
                           MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("班级添加失败", "添加班级提示",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("班级名称已存在", "添加班级提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
