﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinStudent
{
    public partial class FrmStudentList : Form
    {
        public FrmStudentList()
        {
            InitializeComponent();
        }

        //内置委托 Action（不带返回值，可以不带参数，带参最多16个，不带返回值）   
        //Func（带一个返回值，可以不带参数，带参最多16个，带一个返回值）
        private Action reLoad = null;

        private void FrmStudentList_Load(object sender, EventArgs e)
        {
            LoadClasses();
            LoadAllStudentList();
        }

        private void LoadAllStudentList()
        {
            string sql = "SELECT StudentId,studentname,classname,gradename,sex,phone FROM studentinfo a "+
                " INNER JOIN classinfo b ON  b.classid=a.ClassId " +
                " INNER JOIN gradeinfo c ON  c.gradeid=b.gradeid "+
                " where  a.IsDeleted=0 ";
            DataTable dtStudent = SqlHelper.GetDataTable(sql);
            if (dtStudent.Rows.Count > 0)
            {
                foreach (DataRow dr in dtStudent.Rows)
                {
                    string className = dr["ClassName"].ToString();
                    string gradeName = dr["GradeName"].ToString();
                    dr["ClassName"] = className + "--" + gradeName;
                }
            }
            //只显示固定列
            //dgvStudents.AutoGenerateColumns = false;
            dtStudent.Columns.Remove(dtStudent.Columns[3]);
            //绑定数据
            dgvStudents.DataSource = dtStudent;

        }

        private void LoadClasses()
        {
            string sql = "select classId,className,gradeName from classinfo a,gradeinfo b " +
                "where a.gradeid=b.gradeid ";
            DataTable dtClasses = SqlHelper.GetDataTable(sql);
            //组合班级列表
            if (dtClasses.Rows.Count > 0)
            {
                foreach (DataRow dr in dtClasses.Rows)
                {
                    string className = dr["ClassName"].ToString();
                    string gradeName = dr["GradeName"].ToString();
                    dr["ClassName"]=className+"--"+gradeName;
                }
            }
            //添加默认选择项
            DataRow drNew = dtClasses.NewRow();
            drNew["ClassId"] = 0;
            drNew["ClassName"] = "请选择";

            dtClasses.Rows.InsertAt(drNew, 0);

            cboClasses.DataSource = dtClasses;
            cboClasses.DisplayMember = "ClassName";
            cboClasses.ValueMember = "ClassId";
        }
        /// <summary>
        /// 查询学生信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFind_Click(object sender, EventArgs e)
        {
            int classId = (int)cboClasses.SelectedValue;
            string stuName = txtStudent.Text.Trim();

            string sql = "select studentId,studentname,classname,gradename,sex,phone from studentinfo a " +
                " inner join classinfo b on  b.classid=a.classId " +
                " inner join gradeinfo c on  c.gradeid=b.gradeid ";
            sql += " where 1=1 ";
            if(classId>0)
            {
                sql += " and b.Classid=@ClassId ";
            }
            if (string.IsNullOrEmpty(stuName))
            {
                sql += " and StudentName like @StuName1 ";
            }
            sql += " where a.isdeleted=0 ";
            sql += " oder by studentid ";
            MySqlParameter[] paras =
            {
                new MySqlParameter("@ClassId",classId),
                new MySqlParameter("@StuName1","%"+stuName+"%")
            };
            DataTable dtStudent = SqlHelper.GetDataTable(sql);
            if (dtStudent.Rows.Count > 0)
            {
                foreach (DataRow dr in dtStudent.Rows)
                {
                    string className = dr["ClassName"].ToString();
                    string gradeName = dr["GradeName"].ToString();
                    dr["ClassName"] = className + "--" + gradeName;
                }
            }
            //只显示固定列
            //dgvStudents.AutoGenerateColumns = false;
            dtStudent.Columns.Remove(dtStudent.Columns[3]);
            //绑定数据
            dgvStudents.DataSource = dtStudent;
        }
        /// <summary>
        /// 修改或删除功能的实现
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataRow dr = (dgvStudents.Rows[e.RowIndex].DataBoundItem as DataRowView).Row;
                //获取当前点击的单元格
                DataGridViewCell cell = dgvStudents.Rows[e.RowIndex].Cells[e.ColumnIndex];
                if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "修改")
                {
                    //修改操作  打开修改页面，并把stuId给传过去
                    //传值：1.构造函数 2.tag 3.公有变量
                    reLoad = LoadAllStudentList;//赋值委托
                    int stuId = (int)dr["StudentId"];
                    FrmEditStudent frmEdit = new FrmEditStudent();
                    frmEdit.Tag = new Tag (){ ReLoad = reLoad, EditId = stuId};//传值进行调整
                    //3.frmEdit.pubStuId = stuId;
                    frmEdit.MdiParent = this.MdiParent;//指定修改页面的父容器
                    frmEdit.Show();//顶级窗体    MDI容器  如何实现

                }
                else if (cell is DataGridViewLinkCell && cell.FormattedValue.ToString() == "删除")
                {
                    //删除操作  
                    if (MessageBox.Show("确定删除该学生信息？", "删除学生信" +
                        "息",MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        //获取行数据
                     
                        int stuId = int.Parse(dr["StuId"].ToString());
                        //假删除  IsDelete()
                        string sqlDel0 = "updata studentinfo set isdeleted=1 where Studentid=@Studentid";
                        MySqlParameter pata = new MySqlParameter("@Studentid", stuId);
                        int count = SqlHelper.ExecuteNonQuery(sqlDel0, pata);
                        if (count > 0)
                        {
                            MessageBox.Show("该学生删除成功", "删除学生信" +
                            "息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //datagridview数据没有刷新，需要手动刷新
                            DataTable dtStudent = (DataTable)dgvStudents.DataSource;
                            dtStudent.Rows.Remove(dr);
                            dgvStudents.DataSource = dtStudent;
                        }
                        else
                        {
                            MessageBox.Show("该学生删除失败", "删除学生信" +
                             "息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        //真删除  delete  where StuId
                        //string sqlDel1 = "deleted Studentinfo where studentid=@studentid";
                        //MySqlParameter pata1 = new MySqlParameter("@studentid", stuId);
                        //int count1 = SqlHelper.ExecuteNonQuery(sqlDel1, pata1);
                        //if (count1 > 0)
                        //{
                        //    MessageBox.Show("该学生删除成功", "删除学生信" +
                        //"息", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        //    //datagridview数据没有刷新，需要手动刷新
                        //    DataTable dyStudent = (DataTable)dgvStudents.DataSource;
                        //    dyStudent.Rows.Remove(dr);
                        //    dgvStudents.DataSource = dyStudent;
                        //}
                        //else
                        //{
                        //    MessageBox.Show("该学生删除失败", "删除学生信" +
                        //  "息", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                        //    return;
                        //}
                    }
                }
            }
        }

        private void btnDeleted_Click(object sender, EventArgs e)
        {
            //选择框 选中的数据
            //获取要删除的数据StuId
            //判断个数，=0没有选择，提示请选择，大>0继续
            //删除操作   事务  sql事务（数据库启动）和代码中启动
            List<int> listIds = new List<int>();
            for (int i = 0; i < dgvStudents.Rows.Count; i++)
            {
                DataGridViewCheckBoxCell cell = dgvStudents.Rows[i].Cells["colCheck"] as DataGridViewCheckBoxCell;
                bool chk = Convert.ToBoolean(cell.Value);
                if (chk)
                {
                    //获取行数据
                    DataRow dr = (dgvStudents.Rows[i].DataBoundItem as DataRowView).Row;
                    int stuId = (int)dr["StuId"];
                    listIds.Add(stuId);
                }
            }
            //真删除
            if (listIds.Count == 0)
            {
                MessageBox.Show("请选择要删除的学生信息", "删除学生信" +
                    "+息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if (MessageBox.Show("确定删除该学生信息？", "删除学生信" +
                        "+息", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int count = 0;
                    //启动事务
                    using (MySqlConnection conn = new MySqlConnection(SqlHelper.connString))
                    {
                        //事务是通过conn来开启，conn.open状态
                        conn.Open();
                        MySqlTransaction trans = conn.BeginTransaction();
                        //MySqlCommand 事务执行  cmd
                        MySqlCommand cmd = new MySqlCommand();
                        cmd.Transaction = trans;

                        try
                        {
                            foreach (int id in listIds)
                            {
                                cmd.CommandText = "delete from studentinfo where studentid=@studentid";
                                MySqlParameter para = new MySqlParameter("@studentid", id);
                                cmd.Connection = conn;
                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(para);
                                count += cmd.ExecuteNonQuery();
                            }
                            trans.Commit();
                        }
                        catch (MySqlException ex)
                        {
                            trans.Rollback();
                            MessageBox.Show("删除时失败", "删除学生信" +
                                "息", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    if (count == listIds.Count)
                    {
                        MessageBox.Show("所选的学生信息已删除", "删除学生信" +
                             "息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //手动刷新
                        DataTable dtStudent = (DataTable)dgvStudents.DataSource;
                        //dtStudent.DataSource=null
                        string idStr = string.Join(",", listIds);
                        DataRow[] rows=dtStudent.Select("StuId in (" + idStr + ")");
                        foreach (DataRow dr in rows)
                        {
                            dtStudent.Rows.Remove(dr);
                        }
;                        dgvStudents.DataSource = dtStudent;
                    }
                }
            }
        }
        //单例 只有一个实例
        //private static FrmStudentList frmStudentList = null;
        //public static FrmStudentList CreateInstance()
        //{
        //    if(frmStudentList == null|| frmStudentList.IsDisposed)
        //        frmStudentList = new FrmStudentList();
        //    return frmStudentList;
        //}
    }
}
