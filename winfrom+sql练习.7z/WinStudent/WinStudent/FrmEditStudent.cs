﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class FrmEditStudent : Form
    {
        public FrmEditStudent()
        {
            InitializeComponent();
        }
        private int stuId = 0;
        private Action reLoad = null;
        //public int pubStuId=0;
        //public FrmEditStudent(int _stuId)
        //{
        //    InitializeComponent();
        //    stuId = _stuId;
        //}
        private void FrmEditStudent_Load(object sender, EventArgs e)
        {
            InitClasses();//加载班级信息
            InitStuInfo();//加载学生信息
        }
        private void InitStuInfo()
        {
            //获取到StuId
            if(this.Tag!=null)
            {
                Tag tag=(Tag)this.Tag;
                stuId = tag.EditId;
                reLoad = tag.ReLoad;//赋值委托
            }
            //查询数据
            string sql = "select studentname,sex,classId,phone from studentinfo " +
                " where StudentId=@StudentId ";
            MySqlParameter paraId = new MySqlParameter("@StudentId", stuId);
            MySqlDataReader dr = SqlHelper.ExecuteReader(sql, paraId);
            //读取数据   只想前不后退  读一条 丢一条
            if (dr.Read())
            {
                txtStudent.Text = dr["StudentName"].ToString();
                txtPhone.Text= dr["Phone"].ToString();
                string sex= dr["Sex"].ToString();
                if (sex == "男")
                {
                    rbtMale.Checked= true;
                }
                else
                { 
                    rbtFemale.Checked = true;
                }
                int classid = (int)dr["ClassId"];
                cboClasses.SelectedValue = classid;
            }
            dr.Close();
        }
        private void InitClasses()
        {
            //获取数据   ---查询   ---写sql
            string sql = "select classid,classname,gradename from classinfo a,gradeinfo b " +
                " where a.gradeid=b.gradeid ";
            DataTable dtClasses = SqlHelper.GetDataTable(sql);
            //组合班级列表显示项的过程
            if (dtClasses.Rows.Count > 0)
            {
                foreach (DataRow dr in dtClasses.Rows)
                {
                    string className = dr["ClassName"].ToString();
                    string gradeName = dr["GradeName"].ToString();
                    dr["ClassName"] = className + "--" + gradeName;
                }
            }
            //
            cboClasses.DataSource = dtClasses;
            cboClasses.DisplayMember = "ClassName";
            cboClasses.ValueMember = "Classid";
            //cboClasses.SelectedIndex = 0;
        }

        private void btnEidt_Click(object sender, EventArgs e)
        {
            //获取页面信息
            string stuName = txtStudent.Text.Trim();
            int classId = (int)cboClasses.SelectedValue;
            string sex = rbtMale.Checked ? rbtMale.Text : rbtFemale.Text;
            string phone = txtPhone.Text.Trim();
            //判断处理
            if (string.IsNullOrEmpty(stuName))
            {
                MessageBox.Show("姓名不能为空！", "修改学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("电话不能为空！", "修改学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //判断是否存在  姓名+电话 除了这个学生自己，其他数据中是否存在。
            string sql = "select count(1) from studentinfo where StudentName=@StudentName " +
                "and Phone=@Phone and StudentId<>@StudentId";
            MySqlParameter[] paras =
            {
                new MySqlParameter("@StudentName",stuName),
                new MySqlParameter("@Phone",phone),
                new MySqlParameter("@StudentId",stuId)
            };
            object o = SqlHelper.ExecuteScalar(sql, paras);
            if (o != null && o != DBNull.Value && (Convert.ToInt32(o)) > 0)
            {
                MessageBox.Show("该学生已存在！", "添加学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //修改
            string sqlUpdate = "update studentinfo set Studentname=@Studentname,Classid=@Classid" +
                ",Sex=@Sex,Phone=@Phone where StudentId=@StudentId";
            MySqlParameter[] parasUpdate =
{
                new MySqlParameter("@StudentName",stuName),
                new MySqlParameter("@Classid",classId),
                new MySqlParameter("@Sex",sex),
                new MySqlParameter("@Phone",phone),
                new MySqlParameter("@StudentId",stuId)
            };
            int count = SqlHelper.ExecuteNonQuery(sqlUpdate, parasUpdate);
            if (count > 0)
            {
                MessageBox.Show($"学生:{stuName}修改成功！", "修改成功", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                //成功后，马上想刷新学生列表  跨页面刷新  委托 列表页面定义委托，列表页面加载
                //数据列表的这个方法赋值给委托，同时传过去--修改页面；修改页面--定义委托，
                //把传来的委托赋值给页面定义的委托，修改成功后条用委托
                reLoad.Invoke();

            }
            else
            {
                MessageBox.Show($"学生:{stuName}修改失败！", "修改失败", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
