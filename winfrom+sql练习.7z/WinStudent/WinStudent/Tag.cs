﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinStudent
{
    class Tag
    {
        public int EditId { get; set; }
        public Action ReLoad{ get; set; }
    }
}
