﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinStudent
{
    public partial class FrmAddStudent : Form
    {
        public FrmAddStudent()
        {
            InitializeComponent();
        }

        private void FrmAddStudent_Load(object sender, EventArgs e)
        {
            InitClasses();
            rbtMale.Checked = true;
        }

        private void InitClasses()
        {
            //获取数据   ---查询   ---写sql
            string sql = "select classid,classname,gradename from classinfo a,gradeinfo b " +
                " where a.gradeid=b.gradeid ";
            DataTable dtClasses = SqlHelper.GetDataTable(sql);
            //组合班级列表显示项的过程
            if (dtClasses.Rows.Count > 0)
            {
                foreach (DataRow dr in dtClasses.Rows)
                {
                    string className = dr["ClassName"].ToString();
                    string gradeName = dr["GradeName"].ToString();
                    dr["ClassName"] = className + "--" + gradeName;
                }
            }
            //指定数据源
            cboClasses.DataSource = dtClasses;
            cboClasses.DisplayMember = "ClassName";
            cboClasses.ValueMember = "Classid";
            cboClasses.SelectedIndex = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //获取页面信息
            string stuName = txtStudent.Text.Trim();
            int classId = (int)cboClasses.SelectedValue;
            string sex = rbtMale.Checked ? rbtMale.Text : rbtFemale.Text;
            string phone = txtPhone.Text.Trim();
            //判断姓名和电话是否为空
            if (string.IsNullOrEmpty(stuName))
            {
                MessageBox.Show("姓名不能为空！", "添加学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("电话不能为空！", "添加学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //判断姓名+电话数据库是否存在
            string sql = "select count(1) from studentinfo where StudentName=@StudentName " +
                "and Phone=@Phone";
            MySqlParameter[] paras =
            {
                new MySqlParameter("@StudentName",stuName),
                new MySqlParameter("@Phone",phone)
            };
            object o = SqlHelper.ExecuteScalar(sql, paras);
            if (o != null && o != DBNull.Value && (Convert.ToInt32(o)) > 0)
            {
                MessageBox.Show("该学生已存在！", "添加学生", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            //插入操作
            //添加入库 sql 参数 执行 完成返回行数
            string sqlAdd = "insert into studentinfo (Studentname,Classid,Sex,Phone)Values" +
                    "(@Studentname,@Classid,@Sex,@Phone)";
            MySqlParameter[] parasAdd =
{
                new MySqlParameter("@StudentName",stuName),
                new MySqlParameter("@Classid",classId),
                new MySqlParameter("@Sex",sex),
                new MySqlParameter("@Phone",phone)
            };
            int count = SqlHelper.ExecuteNonQuery(sqlAdd, parasAdd);
            if (count > 0)
            {
                MessageBox.Show($"学生:{stuName}添加成功！", "添加成功", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"学生:{stuName}添加失败！", "添加失败", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
