﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Af.Common;
using System.IO;

namespace StudentInformationManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(700, 450);

            //InitGridView();

            // 加载现有的数据
            LoadData();
        }
        //private  void InitGridView()
        //{
        //    grid.ReadOnly = true;
        //    //AddRow(new Student(20201001, "shao", true, "13810012345"));
        //    //AddRow(new Student(20201002, "li", false, "13610022349"));
        //    //AddRow(new Student(20201003, "wang", true, "13810087282"));
        //}

        private void AddRow(Student stu)
        {
            object[] row =
            {
                stu.Id ,
                stu.Name,
                stu.Sex ? "男" : "女",
                stu.Phone
            };

            //grid.Rows.Add(row);
            int rowIndex = grid.Rows.Add(row);
            grid.Rows[rowIndex].Tag = stu; // 关联数据

            // 保存数据
            SaveData();
        }

        private void grid_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                // GetCellAt: 根据点击的位置，判断点中了哪个单元格
                Point p = GetCellAt(grid, e.Location);
                int rowIndex = p.X;

                // 设置选中状态
                grid.ClearSelection();
                if (rowIndex >= 0)
                    grid.Rows[rowIndex].Selected = true;

                // 设置菜单项的状态
                menu_Edit.Enabled = (rowIndex >= 0);
                menu_Delete.Enabled = (rowIndex >= 0);

                contextMenu.Show(grid, e.Location);
            }
        }

        private static Point GetCellAt(DataGridView grid, Point location)
        {
            int row = -1, col = -1;

            // 一共显示的行数: DisplayedRowCount()
            // 第一个显示的行： FirstDisplayedScrollingRowIndex
            // 某行的显示区域:  GetRowDisplayRectangle()
            for (int i = grid.FirstDisplayedScrollingRowIndex; i < grid.FirstDisplayedScrollingRowIndex+grid.DisplayedRowCount(true); i++)
            {
                Rectangle rect = grid.GetRowDisplayRectangle(i, true);
                if (location.Y > rect.Top && location.Y < rect.Bottom)
                {
                    row = i;
                    break;
                }
            }
            for (int k = grid.FirstDisplayedScrollingColumnIndex; k < grid.FirstDisplayedScrollingColumnIndex + grid.DisplayedColumnCount(true); k++)
            {
                Rectangle rect = grid.GetColumnDisplayRectangle(k, true);
                if (location.X > rect.Left && location.X < rect.Right)
                {
                    col = k;
                    break;
                }
            }

            return new Point(row, col);
        }

        private void menu_Add_Click(object sender, EventArgs e)
        {
            StuEditDialog dlg = new StuEditDialog();
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                Student stu = dlg.GetValue();
                AddRow(stu);
            }
        }

        private void menu_Edit_Click(object sender, EventArgs e)
        {
            // 当前行
            int rowIndex = grid.SelectedRows[0].Index;
            // 当前行关联的数据
            Student tag = (Student)grid.Rows[rowIndex].Tag;

            // 弹出对话框
            StuEditDialog dlg = new StuEditDialog();
            dlg.InitValue(tag);
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                Student stu = dlg.GetValue();
                UpdateRow(rowIndex, stu);
            }
        }

        private void UpdateRow(int rowIndex, Student stu)
        {
            grid.Rows[rowIndex].Tag = stu;
            grid[0, rowIndex].Value = stu.Id;
            grid[1, rowIndex].Value = stu.Name;
            grid[2, rowIndex].Value = stu.Sex ? "男" : "女";
            grid[3, rowIndex].Value = stu.Phone;
            SaveData();
        }

        private void menu_Delete_Click(object sender, EventArgs e)
        {
            MyConfirmDialog dlg = new MyConfirmDialog();
            dlg.label.Text = "此操作不可恢复。是否确认删除";

            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                foreach (DataGridViewRow row in grid.SelectedRows)
                {
                    grid.Rows.Remove(row);
                }
                SaveData();
            }
        }
        // 数据的加载
        private void SaveData()
        {
            List<Student> stuList = new List<Student>();
            for (int i = 0; i < grid.Rows.Count; i++)
            {
                Student stu = (Student)grid.Rows[i].Tag;
                stuList.Add(stu);
            }
            string jsonStr = JsonConvert.SerializeObject(stuList, Formatting.Indented);
            AfTextFile.Write("student.dat", jsonStr, AfTextFile.UTF8);
        }
        private void LoadData()
        {
            string jsonFile = "student.dat";
            if(!File.Exists(jsonFile))return;

            // 从文件中读出文本
            string jsonStr= AfTextFile.Read("student.dat", AfTextFile.UTF8);

            // 将jsonStr 转成 List<Student>
            List<Student> stuList = JsonConvert.DeserializeObject<List<Student>>(jsonStr);

            // 显示到表格中
            grid.Rows.Clear();
            foreach (Student stu in stuList)
            {
                AddRow(stu);
            }
        }
    }
}
